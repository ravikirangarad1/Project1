# E-Pass-Generation-System-project
This System Manage All the records of Passes that are issued by the Administrative and also helps to provide online E-Pass Who need to Travel Compulsory.  *Flow Of Project-All User Information Are Stored in database memory And All connection takes through the JDBC, All information is Checked by Admin and he Take a response from the server.   
